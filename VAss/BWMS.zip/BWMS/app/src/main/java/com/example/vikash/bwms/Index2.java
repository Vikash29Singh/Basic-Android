package com.example.vikash.bwms;


import android.content.Intent;
import android.os.Bundle;
//import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.common.SignInButton;

public class Index2 extends AppCompatActivity {
    Button custom_signin_button,registration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index2);



        custom_signin_button= (Button) findViewById(R.id.custom_signin_button);
        registration=(Button) findViewById(R.id.registration);
        registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int2=new Intent(Index2.this, Signup.class);
                startActivity(int2);
            }
        });
        custom_signin_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent int1=new Intent(Index2.this,Dashboard.class);
                //int1.putExtra("Username", user);
                startActivity(int1);
                finish();
            }
        });
    }
}